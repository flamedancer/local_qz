0   ipad
1   iphone
